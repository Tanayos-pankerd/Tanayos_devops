<template>
  <div class="p-6 space-y-6">

    <button class="btn btn-primary">Hello daisyUI</button>

    <div class="card w-full shadow">
      <div class="card-body">
        <h2 class="card-title">daisyUI + Nuxt3</h2>
        <p>ทำงานร่วมกับ Tailwind ได้ทันที</p>
        <div class="card-actions justify-end">
          <button class="btn btn-outline">Action</button>
          <button class="btn btn-outline">Default</button>
<button class="btn btn-outline btn-primary">Primary</button>
<button class="btn btn-outline btn-secondary">Secondary</button>
<button class="btn btn-outline btn-accent">Accent</button>
<button class="btn btn-outline btn-info">Info</button>
<button class="btn btn-outline btn-success">Success</button>
<button class="btn btn-outline btn-warning">Warning</button>
<button class="btn btn-outline btn-error">Error</button>
        </div>
      </div>
    </div>
  </div>
</template>
