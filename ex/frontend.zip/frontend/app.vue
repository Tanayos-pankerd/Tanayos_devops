<!-- app.vue (minimum) -->
<template>
  <NuxtLayout>
    <NuxtPage />
  </NuxtLayout>
</template>

