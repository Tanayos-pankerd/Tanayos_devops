# Nuxt3 Minimal Frontend

## Quick Start (without Docker)
1) `npm install`
2) Create `.env` (optional): NUXT_PUBLIC_API_BASE=http://localhost:7000
3) `npm run dev` then open http://localhost:3000

Default login (matches backend seed):
- admin@example.com / admin1234
